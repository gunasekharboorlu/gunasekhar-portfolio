import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">About Me</h2>
          <div className="mt-2 h-1 w-20 bg-indigo-600 mx-auto"></div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
              alt="Workspace" 
              className="rounded-lg shadow-xl w-full h-auto object-cover"
            />
          </div>
          
          <div className="md:w-1/2">
            <div className="prose prose-lg max-w-none">
              <p className="text-lg text-gray-700 mb-6">
                Hi! My name is Guna Sekhar Boorlu. I am a full-stack developer with expertise in building interactive and responsive web applications. I have a strong passion for web development, AI, and problem-solving.
              </p>
              
              <p className="text-lg text-gray-700 mb-6">
                My journey in web development started with a curiosity about how websites work, which quickly evolved into a passion for creating digital experiences that are both functional and aesthetically pleasing.
              </p>
              
              <p className="text-lg text-gray-700">
                When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, or enhancing my photography skills.
              </p>
              
              <div className="mt-8">
                <a 
                  href="#contact" 
                  className="px-6 py-3 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 transition-colors duration-300"
                >
                  Get In Touch
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;